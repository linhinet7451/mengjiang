# 猛將無雙網路素材搜尋索引

## 宣傳影片
- YouTube: https://www.youtube.com/watch?v=tcxWoC-Rtb8

## 原版玩法與介面參考
- 巴哈姆特新手導覽：https://m.gamer.com.tw/forum/C.php?bsn=22512&snA=1570
- 巴哈姆特入門指南：https://forum.gamer.com.tw/C.php?bsn=22512&snA=3487
- 中文百科遊戲介紹：https://www.newton.com.tw/wiki/%E7%8C%9B%E5%B0%87%E7%84%A1%E9%9B%99

## 使用規則
- reference/ 內內容是考證參考素材，來源為本 repo 既有的截圖與資料。
- 網路來源的圖片、影片與原版 UI 素材版權歸原權利人；未取得授權前，不應直接重新發布或作為公開遊戲素材。
- 可直接放入遊戲的素材，應優先使用自行重繪、原創 SVG/CSS/Canvas、或明確採用 CC0／CC BY 授權的資產。
